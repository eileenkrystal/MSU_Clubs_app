# MSU_Clubs_app
Android app for MSU students to track extra curricular clubs 
